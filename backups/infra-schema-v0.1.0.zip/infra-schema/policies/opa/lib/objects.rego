# Shared helpers for the desired-state guardrail policies.
#
# INPUT MODEL
# -----------
# Every policy in this pack is written for `conftest test --combine`, which
# makes `input` an array whose elements are {"path": <file>, "contents": <doc>}.
# `--combine` is mandatory because almost every meaningful guardrail here is a
# cross-object constraint (a Service references a BackupClass in another file;
# a guest's IP must fall inside a Prefix declared elsewhere). Without --combine
# each document would be evaluated in isolation and those rules could never see
# their siblings.
#
# This library flattens that wrapper -- and any InfraManifest bundles -- into a
# single set `objects` of bare desired-state objects, so individual policy
# files never have to care whether an object arrived loose, inside a bundle, or
# as one document in a multi-document stream.
package infra.lib

import rego.v1

# Every top-level document carried in the combined input.
documents contains doc if {
	some entry in input
	doc := entry.contents
}

# All desired-state objects, with InfraManifest bundles expanded into items.
objects contains obj if {
	some doc in documents
	doc.kind != "InfraManifest"
	obj := doc
}

objects contains obj if {
	some doc in documents
	doc.kind == "InfraManifest"
	some obj in doc.spec.items
}

# Objects of a given kind.
by_kind(kind) := {obj | some obj in objects; obj.kind == kind}

# Composite-key lookup: namespace defaults to "default", mirroring the schema
# and the Pydantic graph layer so the three enforcement layers agree on
# identity.
namespace(obj) := ns if {
	ns := object.get(obj.metadata, "namespace", "default")
}

# Resolve an ObjectRef ({kind, name, namespace?}) to the object it names, if
# present in the combined input. Used by cross-object policies.
resolve(ref) := obj if {
	some obj in objects
	obj.kind == ref.kind
	obj.metadata.name == ref.name
	namespace(obj) == object.get(ref, "namespace", "default")
}

# True when a value is a non-empty string (used for "must be justified" checks).
nonempty_string(x) if {
	is_string(x)
	count(trim_space(x)) > 0
}
